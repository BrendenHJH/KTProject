package com.cobyplain.augmentreality;

/**
 * Created by 임석진 on 2016-11-02.
 */
public interface ScreenObj {
    public void paint(PaintScreen dw);

    public float getWidth();

    public float getHeight();
}
