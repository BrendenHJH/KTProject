package com.cobyplain.augmentreality;

import java.text.DecimalFormat;

import android.location.Location;

abstract public class Marker implements Comparable<Marker> {

    private String ID;	// ID값
    protected String title;	// 타이틀
    private boolean underline = false;	// 밑줄 여부
    private String URL;	// 연동될 URL
    protected PhysicalPlace mGeoLoc;	// 물리적 공간 객체. 실제 장소값을 저장
    // 유저와 물리적 공간 간의 거리(미터 단위)
    protected double distance;
    private boolean active;	// 활성화 여부

    // 드로우 속성
    protected boolean isVisible;	// 보여지는지 여부
    //	private boolean isLookingAt;
//	private boolean isNear;
//	private float deltaCenter;
    public MixVector cMarker = new MixVector();	// 카메라 마커
    protected MixVector signMarker = new MixVector();	// 기호 마커
//	private MixVector oMarker = new MixVector();

    // 장소에 관련된 벡터값들
    protected MixVector locationVector = new MixVector();
    private MixVector origin = new MixVector(0, 0, 0);
    private MixVector upV = new MixVector(0, 1, 0);


    // 생성자. 타이틀과 위도, 경고, 고도값, 링크될 주소와 데이터 소스를 인자로 받는다
    public Marker(String title, double latitude, double longitude, double altitude) {
        super();

        this.active = false;	// 일단 비활성화 상태로

        // 각 속성값 할당
        this.title = title;
        this.mGeoLoc = new PhysicalPlace(latitude,longitude,altitude);

        // 마커의 ID는 '데이터소스##타이틀' 형태이다
        this.ID = title; //mGeoLoc.toString();
    }

    // 타이틀을 리턴
    public String getTitle(){
        return title;
    }

    // URL을 리턴
    public String getURL(){
        return URL;
    }

    // 위도를 리턴
    public double getLatitude() {
        return mGeoLoc.getLatitude();
    }

    // 경도를 리턴
    public double getLongitude() {
        return mGeoLoc.getLongitude();
    }

    // 고도를 리턴
    public double getAltitude() {
        return mGeoLoc.getAltitude();
    }

    // 위치 벡터를 리턴
    public MixVector getLocationVector() {
        return locationVector;
    }
    // 카메라 마커. 최초 위치와 투영될 카메라, 추가되는 x, y 값을 인자로 받는다
    private void cCMarker(MixVector originalPoint, Camera viewCam, float addX, float addY) {

        // 임시 속성들
        MixVector tmpa = new MixVector(originalPoint);
        MixVector tmpc = new MixVector(upV);

        // 위치 벡터를 더하고 뷰 카메라의 벡터값은 뺀 후
        tmpa.add(locationVector); //3
        tmpc.add(locationVector); //3
        tmpa.sub(viewCam.lco); //4
        tmpc.sub(viewCam.lco); //4
        // 카메라의 변환 행렬을 곱한다
        tmpa.prod(viewCam.transform); //5
        tmpc.prod(viewCam.transform); //5

        // 새 임시벡터를 선언하고
        MixVector tmpb = new MixVector();
        // 계산된 벡터들로 카메라 마커와 기호 마커를 사영한다
        viewCam.projectPoint(tmpa, tmpb, addX, addY); //6
        cMarker.set(tmpb); //7
        viewCam.projectPoint(tmpc, tmpb, addX, addY); //6
        signMarker.set(tmpb); //7
    }


    // 마커 위치를 업데이트
    public void update(Location curGPSFix) {
        // 고도 0.0은 아마 POI의 고도가 알려지지 않았고,
        // 유저의 GPS 높이를 세팅해야 한다는 것을 의미한다
        // http://www.geonames.org/export/web-services.html#astergdem 를 참고하여
        // SRTM, AGDEM 또는 GTOPO30등의 DEM모델을 사용해
        // 정확한 높이를 측정 함으로써 이 문제를 개선할 수 있을 것이다

        // 고도 값이 0.0일 경우 현재의 GPS픽스를 이용해 다시 고도값을 얻어온다
        if(mGeoLoc.getAltitude()==0.0)
            mGeoLoc.setAltitude(curGPSFix.getAltitude());

        // compute the relative position vector from user position to POI location
        // 유저 위치로부터 POI 위치 까지의 관계 지점의 벡터를 계산한다
        PhysicalPlace.convLocToVec(curGPSFix, mGeoLoc, locationVector);
    }

    // 그려질 위치를 계산
    public void calcPaint(Camera viewCam, float addX, float addY) {
        cCMarker(origin, viewCam, addX, addY);	// 카메라 마커를 생성
    }

    // 스크린에 실제로 그려주는 메소드
    public void draw(PaintScreen dw) {
        drawCircle(dw);
        drawTextBlock(dw);
    }

    // 스크린에 원을 그린다
    public void drawCircle(PaintScreen dw) {
        // 마커가 표시중인 상태일 경우 출력
        if (isVisible) {
            // 우선 페인트 스크린을 설정한다
            //float maxHeight = Math.round(dw.getHeight() / 10f) + 1;
            float maxHeight = dw.getHeight();
            dw.setStrokeWidth(maxHeight / 100f);
            dw.setFill(false);

            //draw circle with radius depending on distance
            //0.44 is approx. vertical fov in radians
            double angle = 2.0*Math.atan2(10,distance);
            double radius = Math.max(Math.min(angle/0.44 * maxHeight, maxHeight),maxHeight/25f);
            //double radius = angle/0.44d * (double)maxHeight;

            dw.paintCircle(cMarker.x, cMarker.y, (float)radius);
        }
    }

    // 텍스트 블록을 그린다. 일반적으로 URL 등을 담고있는 데이터 소스 등에 사용된다
    public void drawTextBlock(PaintScreen dw) {
        //TODO: 그려지게 될 상한선(최대높이)를 지정
        float maxHeight = Math.round(dw.getHeight() / 10f) + 1;

        //TODO: 거리가 변경되었을 경우에만 텍스트 블록을 변경한다
        String textStr="";	// 출력될 텍스트
        double d = distance;	// 거리. 미터 단위
        DecimalFormat df = new DecimalFormat("@#");	// 숫자 포맷은 @숫자

        // 위치에 따른 자신과의 거리 출력. 1000m 이상은 km로 대체한다
        if(d<1000.0) {
            textStr = title + " ("+ df.format(d) + "m)";
        }
        else {
            d=d/1000.0;
            textStr = title + " (" + df.format(d) + "km)";
        }



    }

    // 거리를 리턴
    public double getDistance() {
        return distance;
    }

    // 거리를 세팅
    public void setDistance(double distance) {
        this.distance = distance;
    }

    // ID를 리턴
    public String getID() {
        return ID;
    }

    // ID를 세팅
    public void setID(String iD) {
        ID = iD;
    }

    // 두 마커를 비교한다. 정확하게는 두 마커의 거리를 비교하여 동일한지 판단한다
    @Override
    public int compareTo(Marker another) {

        Marker leftPm = this;
        Marker rightPm = another;

        return Double.compare(leftPm.getDistance(), rightPm.getDistance());

    }

    // 두 마커가 동일한지 ID로 판단한다
    @Override
    public boolean equals (Object marker) {
        return this.ID.equals(((Marker) marker).getID());
    }

    // 활성화 상태를 리턴
    public boolean isActive() {
        return active;
    }

    // 활성화 상태를 세팅
    public void setActive(boolean active) {
        this.active = active;
    }

    // 아직 미사용
    abstract public int getMaxObjects();

}
