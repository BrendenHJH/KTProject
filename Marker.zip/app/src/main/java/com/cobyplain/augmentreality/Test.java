package com.cobyplain.augmentreality;

import android.location.LocationManager;

/**
 * Created by 임석진 on 2016-10-30.
 */

public class Test {
    LocationManager locationManager;

}
